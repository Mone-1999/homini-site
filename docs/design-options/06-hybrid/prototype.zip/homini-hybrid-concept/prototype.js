const captions = [
  "Один участок. Одна история.",
  "Летняя кухня. Больше поводов собраться.",
  "Беседка. Свой ритм отдыха.",
];
let slideIndex = 0;
function showSlide(index) {
  slideIndex = (index + captions.length) % captions.length;
  document.querySelectorAll('.slide').forEach((slide, i) => {
    slide.hidden = i !== slideIndex;
  });
  document.querySelectorAll('.slider-dot').forEach((button, i) => {
    button.setAttribute('aria-pressed', String(i === slideIndex));
  });
  document.querySelector('#slide-count').textContent = `0${slideIndex + 1} / 03`;
  document.querySelector('#slide-caption').textContent = captions[slideIndex];
}
document.querySelector('#previous-slide').addEventListener('click', () => showSlide(slideIndex - 1));
document.querySelector('#next-slide').addEventListener('click', () => showSlide(slideIndex + 1));
document.querySelectorAll('[data-slide]').forEach(button => {
  button.addEventListener('click', () => showSlide(Number(button.dataset.slide)));
});
document.querySelector('.hero-visual').addEventListener('keydown', event => {
  if (event.key === 'ArrowLeft') { event.preventDefault(); showSlide(slideIndex - 1); }
  if (event.key === 'ArrowRight') { event.preventDefault(); showSlide(slideIndex + 1); }
});
document.querySelectorAll('[data-filter]').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('[data-filter]').forEach(item => {
      item.classList.toggle('active', item === button);
      item.setAttribute('aria-pressed', String(item === button));
    });
    document.querySelectorAll('.product-card').forEach(card => {
      card.hidden = button.dataset.filter !== 'all' && card.dataset.group !== button.dataset.filter;
    });
  });
});
document.querySelector('#prototype-form').addEventListener('submit', event => {
  event.preventDefault();
  document.querySelector('#prototype-status').textContent = 'Это визуальный прототип — заявка не отправлена.';
});
